import { Router } from 'express'
import { AuthorCreationSchema, AuthorSchema, AuthorUpdateSchema } from '../domain/1 Author.js'
import { BookCreationSchema, BookSchema, BookUpdateSchema } from '../domain/2 Book.js'
import type { AuthorService } from '../services/0 AuthorService.js'
import type { BookService } from '../services/BookService.js'
import { zodValidationMiddleware } from './middlewares/1 zodValidation.js'

export function bookRouter(bookService: BookService) {
  const router = Router()

  return router
}

// export function authorRouter(authorService: AuthorService, bookService: BookService) {
//   const router = Router()

//   router.get('/', zodValidationMiddleware(AuthorSchema.partial(), 'query'), (_req, res) => {
//     res.json(authorService.list(res.locals.validation.query).map((author) => author.data))
//   })

//   router.get('/:id', (req, res) => {
//     const { id } = req.params
//     const { data } = authorService.findById(id)
//     res.json(data)
//   })

//   router.post('/', zodValidationMiddleware(AuthorCreationSchema, 'body'), (_req, res) => {
//     console.log(res.locals)
//     const author = authorService.create(res.locals.validation.body)
//     res.status(201).json(author.data)
//   })

//   router.put('/:id', zodValidationMiddleware(AuthorUpdateSchema, 'body'), (req, res) => {
//     const { id } = req.params
//     const author = authorService.update(id, res.locals.validation.body)
//     res.json(author.data)
//   })

//   router.delete('/:id', (req, res) => {
//     const { id } = req.params
//     authorService.delete(id)
//     res.status(204).send()
//   })

//   router.get('/:id/books', (req, res) => {
//     const { id } = req.params
//     const books = bookService.list({ authorId: id })
//     res.json(books.map((book) => book.data))
//   })

//   return router
// }
